import cliente
cliente =cliente.Cliente()

class Promocion:
	def __init__(self,descripcionPromocion):
		self.__idPromocion=None
		self.__descripcionPromocion=descripcionPromocion
		self.__lstCliente=[]
		
	@property	
	def idPromocion(self):
		return self.__idPromocion

	@idPromocion.setter
	def idPromocion(self,idPromocion):
		self.__idPromocion=idPromocion
		
		
	@property	
	def descripcionPromocion(self):
		return self.__descripcionPromocion
	
	@descripcionPromocion.setter	
	def descripcionPromocion(self,descripcion):
		self.__descripcionPromocion=descripcion
	
	
	
	def agregarClientes(self,cliente):
		self.__lstCliente.append(cliente)
	
	def eliminarClientes(self,cualElemento):
		self.__lstCliente.remove(cualElemento)
		
		
