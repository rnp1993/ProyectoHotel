from cliente import Cliente
class Consulta:
    
    def __init__(self,Cliente,fechaConsulta):
        self.__idConsulta=None
        self.__Cliente=Cliente
        self.__fechaConsulta=fechaConsulta
        
    @property    
    def idConsulta(self):
        return self.__idConsulta
    
    @idConsulta.setter
    def idConsulta(self,idConsulta):
        self.__idConsulta=idConsulta
        
    @property    
    def cliente(self):
        return self.__Cliente
    
    @cliente.setter
    def cliente(self,Cliente):
        self.__Cliente=Cliente
    
    @property    
    def fechaConsulta(self):
        return self.__fechaConsulta
    
    @fechaConsulta.setter
    def fechaConsulta(self,fechaConsulta):
        self.__fechaConsulta=fechaConsulta
        
    
        
        