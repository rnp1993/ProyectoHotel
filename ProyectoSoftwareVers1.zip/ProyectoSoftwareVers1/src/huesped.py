from reserva import Reserva

class Huesped:
    def __init__(self,nombre,apellido,dni,Reserva):
        self.__idHuesped=None
        self.__nombre=nombre
        self.__apellido=apellido
        self.__dni=dni
        self.__Reserva=Reserva
        
    @property    
    def idHuesped(self):
        return self.__idHuesped
    
    @idHuesped.setter
    def idHuesped(self,IdHuesped):
        self.__idHuesped=IdHuesped
        
    @property    
    def nombreHuesped(self):
        return self.__nombre
    
    @nombreHuesped.setter
    def nombreHuesped(self,nombreHuesped):
        self.__nombre=nombreHuesped
        
    @property    
    def getApellidoHuesped(self):
        return self.__apellido
    
    @apellidoHuesped.setter
    def apellidoHuesped(self,apellidoHuesped):
        self.__apellido=apellidoHuesped
        
    @property
    def dniHuesped(self):
        return self.__dni
    
    @dniHuesped.setter
    def dniHuesped(self,dni):
        self.__dni=dni
        
    @property    
    def reserva(self):
        return self.__Reserva
    
    
    @reserva.setter
    def reserva(self,Reserva):
        self.__Reserva=Reserva
        
    
        
