class Cliente:
	
	def __init__(self,idCliente,nombreCliente,apellidoCliente,emailCliente,fechaDeNacimiento,esFrecuente):
		self.__idCliente =idCliente
		self.__nombreCliente=nombreCliente
		self.__apellidoCliente=apellidoCliente
		self.__emailCliente=emailCliente
		self.__fechaDeNacimiento=fechaDeNacimiento
		self.__esFrecuente=esFrecuente
		
	
	@property
	def idCliente(self):
		return self.__idCliente
	
	@idCliente.setter
	def idCliente(self,idCliente):
		self.__idCliente=idCliente
		
	@property
	def nombreCliente(self):
		return self.__nombreCliente

	@nombreCliente.setter
	def nombreCliente(self,nombre):
		self.__nombreCliente=nombre

	@property
	def apellidoCliente(self):
		return self.__apellidoCliente

	@apellidoCliente.setter
	def apellidoCliente(self,apellidoCliente):
		self.__apellidoCliente=apellidoCliente
		
	
	@property
	def emailCliente(self):
		return self.__emailCliente
	
	@emailCliente.setter
	def emailCliente(self,emailCliente):
		self.__emailCliente = emailCliente
		

	@property
	def fechaNacimiento(self):
		return self.__fechaDeNacimiento
		
	@fechaNacimiento.setter
	def fechaNacimiento(self,fechaNacimiento):
		self.__fechaDeNacimiento=fechaNacimiento
		
	@property	
	def frecuecia(self):
		return self.__esFrecuente
	
	@frecuencia.setter
	def frecuencia(self,Frec):
		self.__esFrecuente=Frec
		
		
		

