from usuario import Usuario
class Administrador:
	def __init__(self,idAdministrador,Usuario):
		self.__idAdministrador=idAdministrador
		self.__Usuario=Usuario
		
	@property
	def idAdministrador(self):
		return self.__idAdministrador
	
	@idAdministrador.setter
	def idAdministrador(self,idAdm):
		self.__idAdministrador=idAdm

	@property
	def usuario(self):
		return self.__Usuario
	
	@usuario.setter
	def usuario(self,Usuario):
		self.__Usuario = Usuario
