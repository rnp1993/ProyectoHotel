from reserva import Reserva
from habitacion import Habitacion
class Checklist:
    
    def __init__(self,idChecklist,Reserva,Habitacion,hayDeposito,observaciones):
        self.__idCheckList=idChecklist
        self.__Reserva=Reserva
        self.__Habitacion=Habitacion
        self.__hayDeposito=hayDeposito
        self.__observaciones=observaciones
    
    @property    
    def idChecklist(self):
        return self.__idCheckList
    
    @idChecklist.setter
    def idChecklist(self,idChecklist):
        self.__idCheckList=idChecklist
    
        
    @property   
    def reserva(self):
        return self.__Reserva
    
    @reserva.setter
    def reserva(self):
        self.__Reserva=Reserva
        
    @property
    def habitacion(self):
        return self.__Habitacion
    
    @habitacion.setter
    def habitacion(self,Habitacion):
        self.__Habitacion=Habitacion
    
    @property
    def hayDeposito(self):
        return self.__hayDeposito
    
    @hayDeposito.setter
    def hayDeposito(self,hayDeposito):
        self.__hayDeposito=hayDeposito
        
    
    @property    
    def observaciones(self):
        return self.__observaciones
    
    
    @observaciones.setter
    def observaciones(self,observaciones):
        self.__observaciones=observaciones
        
