from reserva import Reserva

class CheckOut:
    
    def __init__(self,idCheckOut,Reserva):
        self.__idCheckOut=idCheckOut
        self.__Reserva=Reserva
        
    @property
    def idCheckOut(self):
        return self.__idCheckOut
    
    @idCheckOut.setter
    def idCheckOut(self,idCheckOut):
        self.__idCheckOut=idCheckOut
        
    @property    
    def reserva(self):
        return self.__Reserva
    
    @reserva.setter
    def reserva(self,Reserva):
        self.__Reserva=Reserva
        
        
    @property    
    def observaciones(self):
        return self.__observaciones
    
    @observaciones.setter
    def observaciones(self,observaciones):
        self.__observaciones=observaciones