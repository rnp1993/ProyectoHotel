import cliente
from tarjeta import Tarjeta

#cliente=cliente.Cliente()

class Reserva:
	def __init__(self,Cliente,fechaInicial,fechaFinal,tipoHabitacion,mail,Tarjeta):
		self.__idReserva=None
		self.__Cliente=Cliente
		self.__fechaInicial=fechaInicial
		self.__fechaFinal=fechaFinal
		self.__tipoHabitacion=tipoHabitacion
		self.__mail=mail
		self.__Tarjeta=Tarjeta


	@property
	def idReserva(self):
		return self.__idReserva
	
	@idReserva.setter
	def idReserva(self,idReserva):
		self.__idReserva=idReserva
		
		
	@property	
	def cliente(self):
		return self.__cliente
	
	@cliente.setter
	def cliente(self,cliente):
		self.__cliente=cliente



	@property
	def fechaInicio(self):
		return self.__fechaInicial

	@fechaInicio.setter
	def fechaInicio(self,fecha):
		self.__fechaInicial=fecha
		
		
	@property	
	def fechaFin(self):
		return self.__fechaFinal

	@fechaFin.setter
	def fechaFin(self,fecha):
		self.__fechaFinal=fecha
		
		
	@property		
	def tipoHabitacion(self):
		return self.__tipoHabitacion
	
	@tipoHabitacion.setter
	def tipoHabitacion(self,tipoHabitacion):
		self.__tipoHabitacion=tipoHabitacion
		
		
	@property	
	def mail(self):
		return self.__mail
	
	@mail.setter
	def mail(self,Mail):
		self.__mail=Mail
		
	@property	
	def tarjeta(self):
		return self.__Tarjeta
	
	@tarjeta.setter
	def tarjeta(self,Tarjeta):
		self.__Tarjeta=Tarjeta
		
		
		
		