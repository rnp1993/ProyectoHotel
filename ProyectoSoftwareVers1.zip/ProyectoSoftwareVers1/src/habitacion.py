from mobiliario import Mobiliario

class Habitacion:
    
    
    def __init__(self,nombreHabitacion,tipoHabitacion,capacidadMax,estadoHabitacion):
        self.__idHabitacion=None
        self.__nombreHabitacion=nombreHabitacion
        self.__tipoHabitacion=tipoHabitacion
        self.__capacidadMax=capacidadMax
        self.__lstMobiliario=[]
        self.__estadoHabitacion=estadoHabitacion
        
        
    @property
    def idHabitacion(self):
        return self.__idHabitacion
    
    
    @idHabitacion.setter
    def idHabitacion(self,idHabitacion):
        self.__idHabitacion=idHabitacion
    
        
    @property
    def nombreHabitacion(self):
        return self.__nombreHabitacion
    
    @nombreHabitacion.setter
    def nombreHabitacion(self,nombre):
        self.__nombreHabitacion=nombre
        
    @property
    def tipoHabitacion(self):
        return self.__tipoHabitacion
    
    @tipoHabitacion.setter
    def tipoHabitacion(self,tipoHabitacion):
        self.__tipoHabitacion=tipoHabitacion
        
    @property 
    def capacidadMax(self):
        return self.__capacidadMax
    
    @capacidadMax.setter
    def capacidadMax(self,capacidad):
        self.__capacidadMax=capacidad
    
    
    def getlstMobiliario(self):
        return self.__lstMobiliario
    
    
    def agregarMobiliarioALaLista(self,Mobiliario):
        self.__lstMobiliario.append(Mobiliario)
        
        
    def quitarMobiliarioALaLista(self,cualElemento):
        self.__lstMobiliario.remove(cualElemento)
        
    @property
    def estadoHabitacion(self):
        return self.__estadoHabitacion
      
    @estadoHabitacion.setter    
    def estadoHabitacion(self,estado):
        self.__estadoHabitacion=estado
        
    
    
    
    
   
        
        
        
        
        