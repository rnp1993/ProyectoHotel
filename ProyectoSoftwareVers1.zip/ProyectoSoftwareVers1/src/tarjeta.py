class Tarjeta:
    
    def __init__(self,nroTarjeta,nombreTitular,codigoSeguridad,fechaVencimiento):
        self.__idTarjeta=None
        self.__nroTarjeta=nroTarjeta
        self.__nombreTitular=nombreTitular
        self.__codigoSeguridad=codigoSeguridad
        self.__fechaVencimiento=fechaVencimiento
        
    
    @property
    def idTarjeta(self):
        return self.__idTarjeta
    
    @idTarjeta.setter
    def idTarjeta(self,idTarjeta):
        self.__idTarjeta=idTarjeta
        
        
    @property    
    def nroTarjeta(self):
        return self.__nroTarjeta
    
    
    @nroTarjeta.setter
    def nroTarjeta(self,nroTarjeta):
        self.__nroTarjeta=nroTarjeta
    
    
    @property    
    def nombreTitular(self):
        return self.__nombreTitular
    
    
    @nombreTitular.setter
    def nombreTitular(self,nombreTitular):
        self.__nombreTitular=nombreTitular
    
    
    @property    
    def codigoSeguridad(self):
        return self.__codigoSeguridad
    
    
    @codigoSeguridad.setter    
    def codigoSeguridad(self,codigoSeguridad):
        self.__codigoSeguridad=codigoSeguridad
        
    
    
    @property
    def fechaVencimiento(self):
        return self.__fechaVencimiento
    
    
    @fechaVencimiento.setter
    def fechaVencimiento(self,fechaVencimiento):
        self.__fechaVencimiento=fechaVencimiento
        
        
    
    