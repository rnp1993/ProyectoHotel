class Mobiliario:

    def __init__(self, idMobiliario,descripcion,estadoMobiliario):
        self.__idMobiliario=idMobiliario
        self.__descripcion=descripcion
        self.__estadoMobiliario=estadoMobiliario
        
    @property    
    def idMobiliario(self):
        return self.__idMobiliario
    
    @idMobiliario.setter
    def idMobiliario(self,idMobiliario):
        self.__idMobiliario=idMobiliario
        
    @property    
    def descripcion(self):
        return self.__descripcion
    
    @descripcion.setter
    def descripcion(self,descripcion):
        self.__descripcion=descripcion
        
    @property    
    def getEstadoMobiliario(self):
        return self.__estadoMobiliario
    
    @estadoMobiliario.setter
    def estadoMobiliario(self,estadoMobiliario):
        self.__estadoMobiliario=estadoMobiliario
        
        
        