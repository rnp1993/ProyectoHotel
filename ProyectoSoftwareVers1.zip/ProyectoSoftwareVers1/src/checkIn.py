from reserva import Reserva
from habitacion import Habitacion
from huesped import Huesped
class CheckIn:
    
    def __init__(self,Reserva,lstHuespedes,tarifa,Habitacion,observaciones):
        self.__idCheckIn=None
        self.__Reserva=Reserva
        self.__lstHuespedes=lstHuespedes
        self.__tarifa=tarifa
        self.__Habitacion=Habitacion
        self.__observaciones=observaciones
        
    @property    
    def idCheckIn(self):
        return self.__idCheckIn
    
    @idCheckIn.setter
    def idCheckIn(self,idCheckIn):
        self.__idCheckIn=idCheckIn
        
    @property    
    def reserva(self):
        return self.__Reserva
    
    @reserva.setter
    def reserva(self,Reserva):
        self.__Reserva=Reserva
        
    def getLstHuespedes(self):
        return self.__lstHuespedes
    
    def agregarHuespedes(self,Huesped):
        self.__lstHuespedes.append(Huesped)
        
    def eliminarHuespedes(self,cualElemento):
        self.__lstHuespedes.remove(cualElemento)
     
     
    @property    
    def observaciones(self):
        return self.__observaciones
    
    @observaciones.setter
    def observaciones(self,observaciones):
        self.__observaciones=observaciones
        
        
        
        