class Usuario:
    
    def __init__(self,idUsuario,usuario,contrasenia,lstPermisos):
        self.__idUsuario=idUsuario
        self.__usuario=usuario
        self.__contrasenia=contrasenia
        self.__lstPermisos=lstPermisos
        
    @property
    def idUsuario(self):
        return self.__idUsuario

    @idUsuario.setter
    def idUsuario(self,idUsuario):
        self.__idUsuario=idUsuario


    @property    
    def usuario(self):
        return self.__usuario


    @usuario.setter
    def usuario(self,usuario):
        self.__usuario=usuario


    @property
    def contrasenia(self):
        return self.__contrasenia 


    
    @contrasenia.setter
    def contrasenia(self,contrasenia):
        self.__contrasenia = contrasenia
        
    
    
    def getLstPermisos(self):
        return self.__lstPermisos
    
    
    
    def agregarPermisos(self,permiso):
        self.__lstPermisos.append(permiso)
        
    
    
    def quitarPermisos(self,cualElemento):
        self.__lstPermisos.remove(cualElemento)
        
        
        