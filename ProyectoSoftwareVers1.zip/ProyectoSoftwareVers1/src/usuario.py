class Usuario:
    
    def __init__(self,usuario,password):
        self.__idUsuario=None
        self.__usuario=usuario
        self.__password=password
      
        
    @property
    def idUsuario(self):
        return self.__idUsuario

    @idUsuario.setter
    def idUsuario(self,idUsuario):
        self.__idUsuario=idUsuario


    @property    
    def usuario(self):
        return self.__usuario


    @usuario.setter
    def usuario(self,usuario):
        self.__usuario=usuario


    @property
    def password(self):
        return self.__password


    
    @password.setter
    def password(self,password):
        self.__password = password
        
    
    

        
        
        